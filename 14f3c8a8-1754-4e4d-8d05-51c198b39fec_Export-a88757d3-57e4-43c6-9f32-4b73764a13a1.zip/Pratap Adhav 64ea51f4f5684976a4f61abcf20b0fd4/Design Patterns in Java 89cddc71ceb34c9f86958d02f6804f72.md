# Design Patterns in Java

Owner: Pratap Adhav

1. Factory design Pattern 
2. 

[Factory-Design-Pattern](Spring-Notes%208965977b801348b9869fec163ce98d2b/Factory-Design-Pattern%209536d350e12244d197bfa0bb250939a8.md)

1.