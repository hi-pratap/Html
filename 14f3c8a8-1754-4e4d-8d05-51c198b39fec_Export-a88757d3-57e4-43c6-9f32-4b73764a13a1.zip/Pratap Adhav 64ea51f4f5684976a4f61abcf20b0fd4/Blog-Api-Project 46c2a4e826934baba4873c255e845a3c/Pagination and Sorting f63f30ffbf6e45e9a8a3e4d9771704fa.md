# Pagination and Sorting

Created: August 2, 2023 12:13 PM

# Pagination and Sorting:

its is mostly required when we are displaying domain  data in tabular format in ui.

Pagination consist of two feilds- page size page number 

![Untitled](Pagination%20and%20Sorting%20f63f30ffbf6e45e9a8a3e4d9771704fa/Untitled.png)

### result

![Untitled](Pagination%20and%20Sorting%20f63f30ffbf6e45e9a8a3e4d9771704fa/Untitled%201.png)

![Untitled](Pagination%20and%20Sorting%20f63f30ffbf6e45e9a8a3e4d9771704fa/Untitled%202.png)