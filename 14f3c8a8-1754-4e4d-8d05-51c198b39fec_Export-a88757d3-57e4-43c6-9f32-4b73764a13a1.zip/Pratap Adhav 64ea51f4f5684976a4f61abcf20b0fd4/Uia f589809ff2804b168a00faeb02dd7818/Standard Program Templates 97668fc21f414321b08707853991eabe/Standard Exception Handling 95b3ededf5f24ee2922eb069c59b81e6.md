# Standard Exception Handling

Project: EZXCHANGE
Description: Standard Way of custom exception Handling
ID: SPT-3
Status: In-Box