# Prerequesites In project

Project: EZXCHANGE
ID: SPT-2
Status: In-Box