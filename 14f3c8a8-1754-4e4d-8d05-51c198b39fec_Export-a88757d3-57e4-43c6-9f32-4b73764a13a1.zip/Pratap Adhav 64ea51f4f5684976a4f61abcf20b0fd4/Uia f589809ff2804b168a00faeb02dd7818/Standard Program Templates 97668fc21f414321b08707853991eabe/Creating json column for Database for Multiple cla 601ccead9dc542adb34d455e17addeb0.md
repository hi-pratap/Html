# Creating json column for Database for Multiple classes

Project: UIA
Description: Adding json type data in Database Column
ID: SPT-4
Status: In-Box