# AWC Set-Up

ID: DOPS-3
Created: July 24, 2023 9:47 PM
Status: Not started

step 1: Click [`https://aws.amazon.com/free/?all-free-tier.sort-by=item.additionalFields.SortRank&all-free-tier.sort-order=asc&awsf.Free Tier Types=*all&awsf.Free Tier Categories=*all`](https://aws.amazon.com/free/?all-free-tier.sort-by=item.additionalFields.SortRank&all-free-tier.sort-order=asc&awsf.Free%20Tier%20Types=*all&awsf.Free%20Tier%20Categories=*all)

![Untitled](AWC%20Set-Up%2007b8dba96b964173a7c7967b6b4fbd6f/Untitled.png)

Username: `hi-Pratap`

passwd `Intelizign@1998`  //root user

# Create new user in AWS Console :

search IAM service

![Untitled](AWC%20Set-Up%2007b8dba96b964173a7c7967b6b4fbd6f/Untitled%201.png)

### itadmin credential

[itadmin_credentials.csv](AWC%20Set-Up%2007b8dba96b964173a7c7967b6b4fbd6f/itadmin_credentials.csv)

### 

# set Billing alaram

1. go to bill dashboard 
2. 

![Untitled](AWC%20Set-Up%2007b8dba96b964173a7c7967b6b4fbd6f/Untitled%202.png)

1.