# Pratap Adhav

<aside>
💡 ***Resume/ Documents / Interview Preparation***

</aside>

***Resume:***

[Resume](Pratap%20Adhav%2064ea51f4f5684976a4f61abcf20b0fd4/Resume%20800ffd9089b345e0a0817175db973a01.md)

---

***Preparation For devops:***

[Preparation](Pratap%20Adhav%2064ea51f4f5684976a4f61abcf20b0fd4/Preparation%20908c1f6d91c94ce883181656614ac71b.csv)

---

Design Pattern in Java:

[Design Patterns in Java](Pratap%20Adhav%2064ea51f4f5684976a4f61abcf20b0fd4/Design%20Patterns%20in%20Java%2089cddc71ceb34c9f86958d02f6804f72.md)

---

***java interview Preparation:***

<aside>
💡 ***Notes***

</aside>

***Spring boot Notes:***

[Spring-Notes](Pratap%20Adhav%2064ea51f4f5684976a4f61abcf20b0fd4/Spring-Notes%208965977b801348b9869fec163ce98d2b.csv)

---

<aside>
💡 ***Project***

</aside>

***UIA***:

[Uia](Pratap%20Adhav%2064ea51f4f5684976a4f61abcf20b0fd4/Uia%20f589809ff2804b168a00faeb02dd7818.md)

---

***EZXCHANGE:***

---

***Blog App:***

[Blog-Api-Project ](Pratap%20Adhav%2064ea51f4f5684976a4f61abcf20b0fd4/Blog-Api-Project%2046c2a4e826934baba4873c255e845a3c.csv)

---

[Java Interviews Hub](Pratap%20Adhav%2064ea51f4f5684976a4f61abcf20b0fd4/Java%20Interviews%20Hub%20e24e46c5787342739714f984a63cb120.md)